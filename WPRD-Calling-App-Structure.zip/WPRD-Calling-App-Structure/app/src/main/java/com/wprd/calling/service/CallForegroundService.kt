package com.wprd.calling.service

import android.app.Service
import android.content.Intent
import android.os.IBinder

class CallForegroundService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
